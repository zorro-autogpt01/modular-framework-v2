High-Level System Overview: GitHub Hub Module

Problem statement and intended users
- What this module solves: Provides a small, self-contained UI + API to inspect GitHub repositories. It can list branches, fetch a branch’s SHA, retrieve repository trees, and read file contents, all through a lightweight FastAPI backend backed by GitHub’s REST API.
- Primary users:
  - Developers and engineers who want an ad-hoc view into a GitHub repository’s structure without leaving a chat/CI environment.
  - Platform operators integrating this module into a larger modular framework who need a GitHub-backed data source.
  - DevOps people provisioning a simple internal tool to explore repo contents during release/testing.

Key components and responsibilities (high level)
- Core API client (GHClient) – modular GitHub REST client
  - Location: modular-framework/modules/github-hub/app/github_api.py
  - Responsibilities:
    - Prepare authenticated requests to GitHub (Authorization: Bearer <token>, Accept: application/vnd.github+json, API version header).
    - Resolve repository identity from URLs (parse_repo).
    - Retrieve repo metadata:
      - get_branches(owner, repo): list all branches
      - get_branch_sha(owner, repo, branch): get the commit SHA for a branch
      - get_tree(owner, repo, branch, recursive): fetch the repository tree (optionally recursive)
      - get_file(owner, repo, path, ref): fetch contents of a file
  - Key behavior:
    - Uses base_url (default https://api.github.com) and a token supplied at runtime.
    - Raises HTTP errors for non-success responses (via r.raise_for_status()).
- API/server layer (FastAPI app)
  - Location: modular-framework/modules/github-hub/app/main.py
  - Responsibilities:
    - Initialize a FastAPI app with CORS enabled to allow cross-origin UI calls.
    - Serve a tiny UI from a static directory (/ui) and provide a root redirect to the UI.
    - Provide token loading logic (read from env vars or Docker secret file) with a helper: _read_token().
    - Create a GHClient instance via _client_from_cfg(cfg) using token and base URL from config or environment variables.
    - Read and validate repository configuration (e.g., repo_url) from config via _owner_repo_from_cfg(cfg).
  - UI integration:
    - The UI is designed to consume the backend via a dynamic API path resolution (see UI code) and is served under /ui with the API endpoints available under /api (proxied or standalone).
- Configuration persistence and security (config store)
  - Location: modular-framework/modules/github-hub/app/store.py
  - Responsibilities:
    - Persist module configuration to disk: CONFIG_PATH defaults to /data/config.json (DATA_DIR = /data).
    - Optional token encryption using Fernet:
      - If a Fernet key is provided via environment variable GH_TOKEN_KEY, the token can be encrypted for storage.
      - When loading config, if token_enc exists and Fernet is available, decrypt to yield a usable token.
      - If no Fernet key is available, fall back to storing token in plaintext as token_plain.
    - read/write helpers:
      - load_config(): reads and returns config dict; decrypts token if possible; supports legacy token_plain.
      - save_config(cfg): writes config; encrypts the token if Fernet is available; otherwise stores plaintext token.
  - Security posture:
    - Token storage is optional encrypted at rest, with the key supplied via an environment variable (GH_TOKEN_KEY).
    - Tokens can also be supplied at runtime via environment (GITHUB_TOKEN) or GITHUB_TOKEN_FILE for docker secrets.
- Frontend UI (static assets and client logic)
  - Location: modular-framework/modules/github-hub/public/js/app.js (plus static assets in public/)
  - Responsibilities:
    - Provide a tiny web UI to interact with the backend API.
    - Dynamically determine the API base path to support both standalone and proxied deployments (e.g., /api, /api/github-hub/api, /api/github-hub/ui, etc.).
    - Implements a local/content cache for file contents (fileCache) to avoid repeated fetches per branch/path.
    - (Truncated in the snippet) Begins integration with a tokenizer/encoder (Tiktoken) logic for encoding content, indicating a capability to process large content with a local/CDN fallback for encoding support.
  - Interaction model:
    - UI calls into the backend under the API path discovered at runtime.
    - Token/credentials flow relies on server-side token provisioning; the UI itself does not store the token in plaintext in code (token management is server-side, backed by store.py).
- Observability and runtime
  - Logging: loguru is used in GH client and store to log status, decryption errors, and warnings about cryptography availability.
  - Error handling: HTTP errors are surfaced via standard FastAPI HTTPException for misconfigurations (e.g., missing token or repo URL).
- Deployment and runtime configuration
  - Data and config directories:
    - Data directory defaults to /data (DATA_DIR); config.json located at /data/config.json.
  - Environment-driven configuration:
    - GITHUB_TOKEN or GITHUB_TOKEN_FILE for authentication.
    - GITHUB_API_BASE to override the GitHub API base URL.
    - GH_TOKEN_KEY for Fernet-based encryption key (base64 urlsafe 32 bytes).
  - UI delivery:
    - Static UI assets served at /ui from the public directory; the API is under /api, with dynamic path calculation to support proxies.
- Data model and flow (what is stored and used)
  - Token handling:
    - In memory: token is read at startup via _read_token() and used to create GHClient.
    - In config: token may be stored encrypted as token_enc or plaintext as token_plain, depending on whether Fernet is configured.
  - Repo configuration:
    - repo_url is expected in the config for identifying the repository (owner and repo derived via parse_repo).
  - GitHub data:
    - Branch names, branch SHAs, tree objects, and file contents are retrieved via GHClient methods and returned to the UI for rendering.

Data flow at a high level (10,000 feet)
- Token provisioning
  - Token is read from environment variables or a secret file (GITHUB_TOKEN or GITHUB_TOKEN_FILE) on server startup.
  - The GHClient is instantiated with this token and an optional base_url (GITHUB_API_BASE or default GitHub API URL).
- Configuration load/save
  - On startup or UI interaction, the module loads existing configuration from /data/config.json via load_config().
  - If a token_enc exists and a Fernet key is provided, the token is decrypted to be used for API calls. If token_plain exists, it is used directly. If no config exists, a new flow is expected from the UI to set up token/repo.
- API and UI interaction
  - The UI (public/js/app.js) dynamically resolves the backend API path, then makes API calls to retrieve branches, SHAs, and repository trees, and to read file contents.
  - GHClient methods perform GitHub REST API calls with the configured token, and results are returned to the UI (e.g., branch lists, tree structures, file contents).
- Data presentation
  - The UI renders the repository structure and file contents, using a client-side cache (fileCache) to minimize repeated network calls.
- Security posture during operation
  - Tokens are transmitted server-to-client only as part of GitHub API responses, not embedded in the frontend source.
  - At rest, tokens can be encrypted in the config file if a Fernet key is provided and used; otherwise, tokens are stored in plaintext in the config.json (not ideal, but supported for flexibility).

Key design decisions ( Why the system is built this way )
- Separation of concerns
  - GHClient encapsulates GitHub interaction details, keeping HTTP logic, headers, and endpoints isolated from the rest of the app.
  - A small FastAPI app acts as the integration layer, handling token provisioning, config loading, and serving the static UI.
  - A dedicated store module abstracts configuration persistence and optional encryption, isolating secrets handling from business logic.
- Optional encryption for tokens
  - Token at-rest encryption via Fernet is optional and controlled by the presence of a key (GH_TOKEN_KEY). This provides a secure default for production while allowing simpler setups if no key is provided.
- UI path-resolution for flexible deployment
  - The frontend includes dynamic API path resolution to work cleanly whether the module is deployed standalone, behind a reverse proxy, or under a framework’s API namespace. This reduces coupling between the frontend and deployment topology.
- Minimal surface area for GitHub access
  - The GHClient implements only the endpoints needed for repository exploration (branches, branch SHA, tree, and file contents). This keeps the surface area focused and reduces potential misuse.
- Observability and resilience
  - Use of loguru for logging and r.raise_for_status for HTTP errors gives clear diagnostics during development and operations.

Security model overview
- Authentication and access
  - GitHub access is authenticated with a personal access token or OAuth token provided at runtime (GITHUB_TOKEN or GITHUB_TOKEN_FILE).
  Authorization is implicit: the module uses the token to access the specified repository; there is no per-user access control in the API layer shown (CORS is open to all origins in this snippet).
- Token at-rest protection
  - If a Fernet key is provided via GH_TOKEN_KEY, the token is encrypted and stored as token_enc (base64-encoded). On load, the module decrypts the token back into memory.
  - If no Fernet key is provided, the token is stored in plaintext as token_plain in the config.json (fallback).
- Secrets management guidance
  - Recommended: supply the token via GITHUB_TOKEN_FILE (secret file in containers) or GITHUB_TOKEN and keep GH_TOKEN_KEY secret in the environment. This minimizes exposure in configs and logs.

Limitations and notable considerations
- API exposure and auth
  - The codebase shows basic token-based access to GitHub, but the REST API endpoints exposed by the FastAPI app are not fully enumerated in the provided snippets. The current design does not demonstrate user-based authentication for the UI/API endpoints (CORS is permissive). Consider adding per-user authentication and endpoint-level authorization for production deployments.
- Encryption key management
  - Fernet-based encryption is optional. If you enable it, you must safely manage GH_TOKEN_KEY (environment variable) to prevent token exposure. Misconfiguration could lead to inability to decrypt stored tokens.
- UI/backend coupling
  - The UI relies on dynamic path resolution to function under various deployment topologies. Ensure consistent reverse-proxy configurations and proper path rewrites to avoid API path mismatches.
- Error handling and resilience
  - The code uses r.raise_for_status() for GitHub requests, which raises exceptions on HTTP errors. A robust production deployment should provide user-friendly error messages, retry/backoff logic, and circuit-breaking behavior for GitHub API rate limits.

Potential future enhancements (suggested)
- Add explicit API endpoints for:
  - Listing branches, getting branch SHAs, fetching repository trees, reading files, and possibly refreshing token/config.
  - Expose config endpoints to update repo_url or base_url without redeploying.
- Implement authentication/authorization for the API layer (e.g., user login, API keys, or OAuth) and tighten CORS policies.
- Add rate-limit awareness and exponential backoff for GitHub API calls.
- Expand config schema validation and provide a UI-driven config wizard to minimize misconfiguration.
- Improve token lifecycle management (token refresh, rotation, and expiry handling).
- Strengthen auditability by emitting structured logs (e.g., repository being accessed, user context if/when added).

Glossary (key terms)
- GHClient: Lightweight wrapper around GitHub REST API calls used by this module.
- Fernet: Symmetric, authenticated cryptography method used for at-rest token encryption.
- token_enc / token_plain: Token storage formats in the configuration file. token_enc is base64-encoded Fernet ciphertext; token_plain is plaintext token.
- DATA_DIR / /data: Directory where runtime data and config.json are stored.
- API base path: The backend API path, typically under /api, with dynamic resolution to support different deployment topologies.
- UI: The static frontend served from /ui that interacts with the backend API to explore repository data.

If you’d like, I can generate a one-page stakeholder-friendly diagram (textual description) or tailor this overview to a particular audience (e.g., security engineers, platform operators, or product managers).