# Browser Module: High-Level System Overview

This document provides a high-level architectural view of the Browser module implemented in modular-framework/modules/browser/server/index.js. It captures the problem space, architecture, data flows, security posture, and key design decisions to help stakeholders understand the system and its interactions with other components.

---

## 1) Problem Statement and Users

- Problem this module addresses:
  - Enable remote browser automation and content interaction via a lightweight HTTP API and a WebSocket-based UI channel.
  - Fetch and proxy web content (with SSRF protection) and render screenshots via headless Chrome/Chromium.
  - Provide lightweight bookmark management and health observability.
  - Support a UI that can issue commands to a live browser instance and relay runtime events.

- Primary users and roles:
  - Front-end UI/UX developers: interact with the browser module to initialize sessions, request content (HTML or proxies), view logs, and issue commands via WebSocket.
  - DevOps/Platform operators: deploy and operate the browser module in a microservice environment, monitor health, scale sessions, and secure access.
  - Automation engineers: use the API endpoints to programmatically launch browser sessions, fetch pages, take screenshots, and manage bookmarks as part of automated pipelines.

---

## 2) Architecture Overview

The Browser module is implemented as an Express-based HTTP API with a WebSocket bridge and a headless Chrome/Chromium automation engine. Core components and responsibilities:

- API Layer (Express)
  - /api/sessions
    - POST: Create a new browser session (launchSession). Returns a sessionId.
    - DELETE: Close an existing session (not fully visible in the snippet, but implied by the route).
  - /api/proxy
    - GET: Proxy an arbitrary URL through the server with SSRF protection. Supports non-HTML content passthrough and HTML content patching (base tag injection) to repair relative URLs.
  - /api/screenshot
    - GET: Render a URL to a PNG screenshot using Puppeteer.
  - /api/bookmarks
    - GET/POST: Simple in-memory bookmark store (title, url).
  - /api/bookmarks/:id
    - DELETE: Remove a bookmark by id.
  - /health
    - GET: Health check endpoint.
  - WebSocket upgrade endpoint
    - Upgrade path: /api/ui/ws?id=...
    - Establishes a WebSocket connection to push commands to a specific UI client instance (uiClients map).

- WebSocket Bridge (UI Commands Channel)
  - wss (WebSocketServer) accepts upgrades on /api/ui/ws.
  - UI clients are keyed by a provided id (query parameter).
  - server maintains uiClients: Map<id, WebSocket>.
  - sendCmd(id, cmd): Helper to push a command object to a specific UI client.

- Browser Automation Engine
  - Puppeteer-based browser control (puppeteer-core).
  - Dynamically locates a Chrome/Chromium executable (findChrome) using a candidate list and environment override.
  - launchSession(opts):
    - Launches a headless browser with remote debugging port auto-assigned.
    - Creates a new Page and applies viewport and extra HTTP headers if provided.
    - Sets up event streaming (console, request, response) into an in-memory events array for potential SSE/logging (not exposed as an endpoint in the provided snippet).
    - Tracks session metadata in a Map (sessions) keyed by a unique id (uuidv4()).
    - Returns session info: { id, debugPort, targetId }.
  - Data stored per session: browser instance, page, debug port, devtools targetId, headers, and event stream.

- Network & Security Helpers
  - isPrivateIP(ip): Basic check for private IPv4 ranges (10/172.16-31/192.168) and localhost variants.
  - DNS-based SSRF protections in /api/proxy:
    - Validates the target URL and ensures http/https protocols only.
    - Resolves DNS for the hostname and blocks private IPs.
  - Content handling:
    - Non-HTML content is passed through as-is with minimal header passthrough (excluding Content-Security-Policy headers).
    - HTML content is patched by injecting a <base href="..."> tag to repair relative URLs, ensuring that relative links resolve correctly when proxied.
  - Optional authorization hook (authOk) is present but currently returns true (DEV-ONLY). A token-based check is scaffolded but commented out in the snippet.

- Data Model
  - uiClients: Map<string, WebSocket> – tracks active UI WebSocket connections by id.
  - sessions: Map<string, { browser, page, debugPort, targetId, headers, events }> – stores per-session browser/page state and runtime events.
  - bookmarks: In-memory array of { id, title, url, created }.

- Observability
  - In-session event collection for console/logging, requests, and responses (captured via Puppeteer's page event listeners). These are accumulated in a capped in-memory array (events) per session for potential delivery via an API or SSE (the snippet prepares data but does not show an active SSE endpoint).

---

## 3) Data Flow (10,000 ft)

- Session lifecycle
  - Client sends POST /api/sessions with optional viewport and headers.
  - Server invokes launchSession({ viewport, headers }):
    - Locates Chrome/Chromium binary (findChrome).
    - Launches a headless browser with remote debugging enabled on a dynamic port.
    - Creates a Puppeteer Page, applies viewport and extra HTTP headers if any.
    - Subscribes to page events (console, request, response) and stores them in a per-session event log.
    - Generates a unique session id, stores session context in the sessions map, and returns { sessionId } to the client.
  - Client retains sessionId for subsequent interactions.

- Page proxy and content handling
  - Client requests /api/proxy?url=<target>.
  - Server validates URL, resolves DNS, and blocks private IP addresses.
  - For non-HTML responses, server forwards content and preserves most headers (excluding CSP).
  - For HTML responses, server patches HTML by inserting a base tag to fix relative URLs, then returns the transformed HTML along with appropriate content-type.
  - This enables a browser-agnostic proxy path for HTML content while mitigating simple SSRF risks.

- Desktop/mobile UI integration (WebSocket-based)
  - Client connects to /api/ui/ws?id=<id> to establish a persistent WebSocket channel for UI commands.
  - Server stores the WebSocket in uiClients[id].
  - Commands can be sent to a specific UI client via sendCmd(id, cmd), enabling real-time browser control or UI interactions.

- Screenshot capture
  - Client requests /api/screenshot?url=<target>.
  - Server launches a separate Puppeteer instance (via findChrome), navigates to the URL, waits, captures a PNG, and returns the image.

- Bookmarks and health
  - Bookmarks API (in-memory): GET/POST/DELETE to manage bookmarks for quick reuse of URLs.
  - Health endpoint: /health reports current health status.

- Session termination
  - Client can request DELETE /api/sessions/:id to close and clean up resources for a given session (browser/page).

---

## 4) Security Model

- Authentication
  - There is a potential control token (CONTROL_TOKEN) from environment variables, and a skeleton authOk(req) function.
  - In the provided code, authOk always returns true (DEV-ONLY), meaning no real authentication is enforced in this snippet.
  - Production deployments should enable token-based authentication, possibly with:
    - Bearer token validation (e.g., Authorization header).
    - IP allowlists or mutual TLS.
    - Rate limiting and per-session scoping.

- SSRF and network security
  - The /api/proxy endpoint enforces:
    - URL protocol must be http or https.
    - DNS resolution of the hostname and explicit blocklisting of private IP addresses (basic SSRF protection).
  - HTML responses are patched to fix relative URLs but content is still served from the target; additional controls could be added (e.g., CSP enforcement or domain allowlists) to reduce risk.

- Content handling safeguards
  - Non-HTML content is passed through with minimal header transfer, which may require further hardening in production to avoid leaking CSP headers or other sensitive data.

- WebSocket access
  - WebSocket upgrade is gated by the authOk check (currently a DEV placeholder that always passes). In production, ensure proper authentication/authorization for WebSocket upgrades to prevent unauthorized control of browser sessions.

- Data isolation and scope
  - Sessions and events are stored in in-memory Maps within the module process, implying:
    - Data is ephemeral and will be lost on restart.
    - Not suitable for multi-instance coordination without a shared store.
  - For production, consider persisting session state and events to a centralized store (e.g., Redis) and using a lockless coordination mechanism.

- Dependency and environment considerations
  - Relies on a Chrome/Chromium binary present on the host or container (via CHROME_BIN_CANDIDATES or PUPPETEER_EXECUTABLE_PATH).
  - Uses puppeteer-core, so the exact Chrome version must be compatible with the Puppeteer version in use.
  - Exposed endpoints should be served behind a trusted network boundary and possibly TLS.

---

## 5) Key Design Decisions

- Headless browser as a service per session
  - Each session launches its own Puppeteer-managed browser instance with a dedicated page, isolating workloads and enabling per-session configuration (viewport, headers).

- Dynamic devtools port discovery
  - The browser is launched with a remote debugging port assigned by Chrome (port 0) and the server deduces the port from the wsEndpoint, enabling dynamic, conflict-free debugging.
  
- Minimal, in-memory state with immediate API surface
  - Sessions and bookmarks are stored in memory for simplicity and speed, enabling rapid prototyping and less operational overhead.
  - WebSocket-based UI command channel enables real-time control and streaming of runtime events.

- Content proxying with HTML patching for reliability
  - The /api/proxy endpoint patches HTML to inject a base tag. This helps resolve relative links when content is loaded through the proxy, improving reliability in embedded UIs and cross-origin use-cases.

- Lightweight SSRF protections
  - DNS-based hostname resolution and private IP filtering mitigate common SSRF vectors without adding heavy infrastructure.

- Extensibility and testability
  - The modular code structure (separate endpoints for sessions, proxy, screenshot, bookmarks, and health) supports incremental feature expansion and easier testing.

- Observability hooks
  - Page-level events (console, request, response) are captured and stored per session, enabling potential later exposure via an API or UI, and facilitating debugging.

---

## 6) Non-Functional Considerations

- Scalability
  - Current design uses per-session Chrome instances. This is straightforward but may become resource-intensive at scale.
  - Consider pooling or reusing browser contexts, or implementing a multi-tenant strategy with resource quotas.

- Reliability
  - In-memory state means session data is ephemeral. Implement persistence if long-lived sessions or cross-instance coordination are needed.
  - Add robust error handling, retries, and timeouts for external network calls (proxy and screenshot endpoints).

- Security hardening
  - Replace the DEV-only authOk with a proper authentication/authorization mechanism.
  - Introduce rate limiting, request validation, and per-session permissions.
  - Consider CSP and cookie handling for proxied HTML content to prevent leakage of credentials or cross-site scripting concerns.

- Operational monitoring
  - Expose metrics (e.g., number of active sessions, memory/CPU consumption per session) and logging for troubleshooting.
  - Monitor Puppeteer process lifecycles and automatically recycle unhealthy sessions.

---

## 7) Summary for Stakeholders

- The Browser module provides a focused service enabling:
  - Remote browser session management via REST API.
  - HTML content proxying with basic SSRF protections and URL normalization.
  - On-demand webpage screenshots using headless Chrome.
  - Lightweight bookmark management.
  - A WebSocket-based channel for UI-driven command and control of browser sessions.

- It is designed for rapid iteration and developer-friendly experimentation, but in production it should be hardened (authentication, persistent state, resource controls, and enhanced security) and, if needed, scaled with a distributed storage and orchestration strategy.

If you’d like, I can tailor this overview to align with your organization’s specific architecture diagram, security posture, or compliance requirements, or produce a diagrammatic view (e.g., component diagram, dataflow diagram) to accompany this document.