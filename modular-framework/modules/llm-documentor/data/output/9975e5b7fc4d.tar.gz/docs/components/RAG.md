# High-Level System Overview

Problem statement and users
- Problem: Provide a lightweight, production-ready Retrieval-Augmented Generation (RAG) system for small organizations. It ingests diverse sources (GitHub repositories, PDFs, and plain text files), converts them into dense vector embeddings, stores them in a vector database, and supports fast retrieval-backed Q&A or content generation.
- Primary users: Developers, knowledge managers, data scientists, IT operations, and other knowledge workers who need quick access to internal code, documents, and conversation history.

Key capabilities
- Ingests: GitHub repos, PDFs, and text files.
- Embeddings: OpenAI v1 async embeddings (text-embedding-3-small by default).
- Vector store: Qdrant (Cosine distance; multiple collections).
- Cache: Redis (for fast retrieval/caching).
- Retrieval/QA: Vector-based search to support RAG flows (not fully shown in code excerpt but implied by architecture).
- API surface: FastAPI application (including an admin API namespace).

Architecture overview
- Core components
  - FastAPI Service
    - Exposes HTTP endpoints (including admin API under /admin-api) and serves as the orchestration layer for ingestion, embedding, and retrieval workflows.
    - Configured with permissive CORS (adjust for production).
  - Embedding Service
    - Asynchronous, token-aware embedding provider using OpenAI AsyncOpenAI client.
    - Token handling and truncation to stay within model limits.
    - Micro-batching with per-item fallback to handle partial failures without blocking entire batch.
  - Chunking Service
    - Smart chunking logic for code and text:
      - CodeChunk data model to describe chunks (content, file path, repo, language, line range, chunk type).
      - Supports language-aware chunking, token-based sizing, boundary-aware flushing, and overlap management.
      - Ensures chunks stay within token budget (CHUNK_TOKENS_TARGET and CHUNK_TOKENS_HARD).
  - Data Store Layer (Vector & Cache)
    - Qdrant vector store with multiple collections:
      - code, documents, conversations
      - Each collection uses the same embedding dimension (EMBED_DIM) and COSINE distance.
      - Collection metadata includes vector dimension and distance to support similarity search.
    - Redis cache for quick retrieval results to reduce redundant embeddings/vector searches.
  - Ingestion & Data Model
    - Ingested content is chunked (textual or code blocks) with language metadata derived from file suffixes.
    - CodeChunk captures granularity like start_line and end_line for traceability.
  - Embedding and Tokenization
    - Tokenization via tiktoken (cl100k_base) to respect model/input limits.
    - EMBED_DIMS mapping for multiple embedding models (text-embedding-3-small, -large, ada-002).
  - Observability and Logging
    - Loguru-based logging to a file with rotation (rag_system.log), retention policy, and INFO level.

Data model and configuration details
- Embedding and model configuration
  - OPENAI API key sourced from environment (OPENAI_API_KEY).
  - AsyncOpenAI client instance created for embedding calls.
  - Default models (configurable via environment):
    - RAG_EMBED_MODEL: e.g., "text-embedding-3-small" (1536 dims)
    - RAG_SUMMARY_MODEL, RAG_ANSWER_MODEL: e.g., "gpt-4o-mini"
  - EMBED_DIM chosen from EMBED_DIMS mapping to align with chosen embedding model.
- Collections
  - code: size EMBED_DIM, distance COSINE
  - documents: size EMBED_DIM, distance COSINE
  - conversations: size EMBED_DIM, distance COSINE
- Token/Chunking thresholds
  - EMBED_MICROBATCH: micro-batch size for embeddings
  - MAX_FILE_TOKENS: threshold to skip absurdly large files
  - MINIFIED_LINE_LEN_THRESHOLD: heuristic for minified files
  - CHUNK_TOKENS_TARGET and CHUNK_TOKENS_HARD: token budget controls for chunking
  - EMBED_TOKEN_LIMIT: max tokens allowed for embedding input (used during truncation)
  - CHUNKING uses cl100k_base tokenizer

Data flow (10,000 ft)
- Ingestion
  - Content sources: GitHub repos, PDFs, and text files.
  - Source data is routed to the ChunkingService and EmbeddingService.
- Chunking
  - Content is split into CodeChunk objects (for code) or chunked text blocks.
  - Token budgets enforced (target and hard limits), with overlap to preserve context.
  - Language metadata inferred from file extension.
- Embedding
  - Text is truncated to token limits, then embedded via OpenAI embeddings API.
  - Embeddings are produced in micro-batches with per-item fallback for failures.
  - Resulting embeddings are aligned with collection dimensions.
- Storage
  - Embeddings are stored in Qdrant across the code, documents, and conversations collections.
  - Metadata (e.g., file_path, repo_name, language, start_line, end_line) is stored with vectors.
- Retrieval
  - User queries are converted to embeddings and searched against the relevant collection (e.g., code or documents) using cosine similarity.
  - Redis cache is used to speed up repeated queries or intermediate results.
- API/Presentation
  - FastAPI serves endpoints for ingestion, retrieval, and admin operations.
  - Admin API namespace provides management capabilities (details not fully shown in excerpt).

Security and compliance considerations
- Access control
  - The code shows a public-facing FastAPI app with a permissive CORS policy ("allow_origins": ["*"]). This is acceptable for development but should be tightened for production.
  - Admin API is separated under the ADMIN_API_PREFIX but access control and authentication mechanisms are not shown in the excerpt. Consider implementing authentication (OAuth2/JWT), IP allowlists, and role-based access.
- Secrets and keys
  - OpenAI API key is read from environment variables; ensure secret management practices (e.g., vaults, secret managers) in production.
- Data at rest
  - Data stored in Qdrant and Redis; evaluate encryption at rest and access controls for these services.
- Data governance
  - Embeddings and raw content may expose sensitive information; consider data handling policies, data minimization, and user consent when ingesting proprietary data.

Key design decisions
- Async, micro-batched embedding with robust fallback
  - Uses AsyncOpenAI for non-blocking operations.
  - Micro-batching improves throughput; per-item fallback ensures a single bad input doesn't derail a batch.
- Token-aware chunking
  - Tokenization via tiktoken with cl100k_base to respect model limits.
  - CHUNK_TOKENS_TARGET and CHUNK_TOKENS_HARD enforce practical chunk sizes; hard splitting preserves context and avoids overlong inputs.
- Data organization by collection/type
  - Separate Qdrant collections for code, documents, and conversations enable targeted similarity search and easier policy enforcement per data type.
  - All collections share the same embedding dimension for consistency.
- Cache-first retrieval
  - Redis cache helps accelerate repeated queries and reduces pressure on the embedding service and vector store.
- Extensibility and environment-driven configuration
  - Model names, embedding dimensions, and collection behavior are configurable via environment variables, enabling quick iteration and deployment across environments.
- Observability
  - Centralized logging with rotation and retention for operational visibility.

Operational considerations and recommendations
- Security hardening
  - Switch from universal CORS to restricted origins in production.
  - Implement authentication/authorization for admin endpoints.
  - Secure Redis and Qdrant (passwords, TLS where supported).
- Performance & scaling
  - Ensure Qdrant and Redis are horizontally scalable or appropriately provisioned for load.
  - Tune EMBED_MICROBATCH and chunking parameters (CHUNK_TOKENS_TARGET/HARD) based on workload.
  - Monitor OpenAI API usage and latency; consider retry/backoff strategies for transient failures.
- Data governance
  - Define retention policies for ingested content and embeddings.
  - Implement data provenance and chunk/file lineage for traceability (already partially supported via CodeChunk fields).
- Extensibility
  - The architecture supports adding new ingestion sources (e.g., PDFs, web pages) and new data types with minimal changes.
  - Consider adding more sophisticated retrieval prompts or post-processing for answer synthesis.

Appendix: notable constants and components (from rag_system.py)
- Models (configurable via env)
  - RAG_EMBED_MODEL (default: "text-embedding-3-small") – 1536 dims
  - RAG_SUMMARY_MODEL, RAG_ANSWER_MODEL (default: "gpt-4o-mini")
- Dimensions and mappings
  - EMBED_DIMS: {"text-embedding-3-small": 1536, "text-embedding-3-large": 3072, "text-embedding-ada-002": 1536}
  - EMBED_DIM derived from RAG_EMBED_MODEL
- Collections
  - "code", "documents", "conversations" (all with Distance.COSINE)
- Token and chunking controls
  - EMBED_MICROBATCH
  - MAX_FILE_TOKENS
  - MINIFIED_LINE_LEN_THRESHOLD
  - CHUNK_TOKENS_TARGET
  - CHUNK_TOKENS_HARD
  - EMBED_TOKEN_LIMIT
- Data models
  - CodeChunk: content, file_path, repo_name, language, start_line, end_line, chunk_type
- Infrastructure
  - QdrantClient (URL from QDRANT_URL)
  - Redis (host from REDIS_HOST)
  - OpenAI AsyncOpenAI client (api_key from OPENAI_API_KEY)
  - Tokenizer: tiktoken cl100k_base

If you’d like, I can turn this into a slide-ready brief, a one-page executive summary, or a detailed component diagram with data flows and REST API endpoints (based on the rest of the codebase).