# Modular Framework Documentation

## High-Level System Overview

### Problem Statement and Users

The Modular Framework aims to provide a robust solution for small organizations to efficiently manage and retrieve information from various data sources, including GitHub repositories, PDFs, and text files. The primary users of this system are developers and data scientists who require a streamlined way to ingest, process, and query large volumes of text data, leveraging advanced AI capabilities for natural language processing and information retrieval.

### Architecture Overview

The architecture of the Modular Framework consists of several key components organized into a modular structure. Each module is designed to handle specific functionalities, ensuring scalability and maintainability. The main components include:

1. **Framework**: This core component manages the overall application setup, including configuration files and the web server setup (Nginx).
   - **Dockerfile**: Defines the environment for the framework.
   - **nginx.conf**: Configuration for the Nginx server.
   - **index.html**: The main entry point for the framework's web interface.

2. **Modules**: Each module serves a distinct purpose and can operate independently or in conjunction with others.
   - **RAG (Retrieval-Augmented Generation)**: This module ingests various data types, processes them using OpenAI's API for embeddings, and stores them in a vector database (Qdrant) for efficient retrieval.
   - **Browser**: A module that provides a web-based interface for interacting with the system, allowing users to query and visualize data.
   - **GitHub Hub**: Integrates with GitHub's API to manage and retrieve repository data.
   - **LLM Chat**: Facilitates chat interactions using language models, allowing users to engage in conversations based on ingested data.

3. **Data Storage**: The system utilizes Redis for caching and Qdrant as a vector store for managing embeddings and facilitating quick searches.

### Data Flow at 10,000 ft

1. **Data Ingestion**: Users upload documents (e.g., PDFs, text files) or connect to GitHub repositories. The RAG module handles the ingestion process, extracting relevant data and preparing it for embedding.
   
2. **Embedding Generation**: The RAG module utilizes OpenAI's AsyncOpenAI client to generate embeddings for the ingested text. This process includes tokenization, chunking, and micro-batching to optimize performance and manage token limits.

3. **Storage**: Generated embeddings are stored in Qdrant, organized into collections based on their type (e.g., code, documents, conversations). Redis is used for caching frequently accessed data to enhance retrieval speed.

4. **Querying**: Users interact with the Browser module to issue queries. The system retrieves relevant embeddings from Qdrant, processes them, and presents the results in a user-friendly format.

5. **User Interaction**: The LLM Chat module allows users to engage in conversational queries, leveraging the ingested data to provide contextually relevant responses.

### Security Model

The Modular Framework incorporates several security measures to protect user data and ensure safe interactions:

- **CORS Middleware**: Configured to allow cross-origin requests while providing options to tighten security for production environments.
- **Environment Variables**: Sensitive information such as API keys and database URLs are managed through environment variables, preventing hardcoding in the source code.
- **Logging**: The system logs significant events and errors, allowing for monitoring and troubleshooting while ensuring sensitive information is not exposed in logs.

### Key Design Decisions

1. **Modular Architecture**: The decision to structure the framework into distinct modules allows for flexibility, enabling teams to work on different components simultaneously and facilitating easier updates and maintenance.

2. **Asynchronous Processing**: Utilizing asynchronous programming with the OpenAI API enhances performance, allowing for non-blocking operations during embedding generation.

3. **Micro-Batching**: Implementing micro-batching for embedding generation helps manage API rate limits and optimizes processing time, ensuring that large datasets can be handled efficiently.

4. **Use of Qdrant for Vector Storage**: Choosing Qdrant as the vector store provides a robust solution for managing embeddings, allowing for efficient similarity searches and retrieval operations.

5. **Caching with Redis**: Integrating Redis for caching frequently accessed data improves the overall performance of the system, reducing latency during data retrieval.

This documentation provides a comprehensive overview of the Modular Framework, outlining its purpose, architecture, data flow, security measures, and design decisions, making it suitable for stakeholders and technical teams alike.