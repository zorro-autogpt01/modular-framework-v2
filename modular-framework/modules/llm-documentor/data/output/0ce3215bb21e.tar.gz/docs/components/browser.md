# High-Level System Overview

## Problem Statement and Users

The modular framework aims to provide a versatile and efficient browser automation and interaction platform. It caters primarily to developers and testers who require automated browsing capabilities for tasks such as web scraping, testing web applications, and capturing screenshots. The system allows users to interact with web pages programmatically while ensuring security and performance.

## Architecture Overview

The architecture of the browser module consists of several key components:

1. **Express Server**: The core of the application is built on Express, which handles incoming HTTP requests and serves as the main entry point for the API.

2. **WebSocket Server**: A WebSocket server is integrated to facilitate real-time communication between the server and connected clients, allowing for interactive sessions.

3. **Puppeteer**: The module utilizes Puppeteer, a Node.js library, to control headless Chrome or Chromium browsers for automated browsing tasks.

4. **HTTP Proxy**: The system includes a proxy mechanism to handle requests to external URLs securely, with built-in protections against SSRF (Server-Side Request Forgery).

5. **Bookmark Management**: A simple in-memory storage for bookmarks allows users to save and manage URLs.

6. **Health Check Endpoint**: A dedicated endpoint to monitor the health status of the service.

### Component Interaction

- **Client Requests**: Clients interact with the server through RESTful API endpoints for various functionalities, including session management, proxying requests, and taking screenshots.
- **WebSocket Communication**: For real-time updates and commands, clients can establish WebSocket connections, enabling them to receive event streams and send commands to the browser sessions.
- **Session Management**: Each session is uniquely identified and managed, allowing multiple concurrent sessions to operate independently.

## Data Flow at 10,000 ft

1. **Client Request**: A client sends a request to the Express server (e.g., to create a session or proxy a URL).
2. **Session Launch**: If a session is requested, the server launches a Puppeteer-controlled browser instance.
3. **Event Handling**: The server listens for events from the browser (e.g., console messages, network requests) and pushes these events to the connected WebSocket clients.
4. **Proxy Requests**: For proxy requests, the server validates the URL, checks for private IP addresses, and forwards the request to the target URL, returning the response to the client.
5. **Bookmark Management**: Clients can create, retrieve, or delete bookmarks via dedicated API endpoints, with data stored in memory.
6. **Health Monitoring**: Clients can check the health of the service through a dedicated endpoint.

## Security Model

The security model of the browser module includes several layers of protection:

- **Authorization**: A control token mechanism is in place to restrict access to certain endpoints, although it is currently set to allow all requests in development mode.
- **Input Validation**: The system validates incoming URLs to ensure they conform to expected formats and protocols, preventing malicious requests.
- **IP Address Filtering**: The server checks resolved IP addresses against a list of private IP ranges to mitigate SSRF attacks.
- **Content Security Policy**: The server sets appropriate Content Security Policy headers to prevent clickjacking and other attacks when serving HTML content.

## Key Design Decisions

1. **Headless Browsing**: The decision to use headless Chrome via Puppeteer allows for efficient and resource-friendly automated browsing without the need for a graphical user interface.
2. **WebSocket Integration**: Implementing WebSocket support enables real-time communication, which is essential for interactive applications and monitoring browser events.
3. **In-Memory Bookmark Storage**: For simplicity and speed, bookmarks are stored in memory, allowing for quick access and management. However, this could be extended to a persistent storage solution for production use.
4. **CORS and Static File Serving**: The server is configured to handle CORS requests and serve static files, making it suitable for integration with front-end applications.

This modular framework provides a robust foundation for browser automation tasks while ensuring security and flexibility for developers and testers.