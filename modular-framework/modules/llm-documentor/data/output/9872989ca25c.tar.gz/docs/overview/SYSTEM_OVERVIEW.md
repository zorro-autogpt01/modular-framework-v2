High-Level System Overview

Purpose
- Provide a concise, stakeholder-friendly view of the RAG-oriented system in the modular-framework repository.
- Explain what the system does, how it’s organized, how data flows end-to-end, the security posture, and the key design decisions that guide implementation and future evolution.

Problem statement and users
- Problem: Small-to-medium organizations want to quickly extract and surface knowledge from heterogeneous data sources (GitHub repositories, PDFs, text files) using a retrieval-augmented generator.
- Primary users:
  - Knowledge workers and engineers who need accurate, context-aware answers drawn from code, documents, and conversations.
  - Admins and operators who deploy, monitor, and maintain the vector store and embedding pipelines.
- Primary use cases:
  - Ingest large repositories and documents into a searchable knowledge store.
  - Answer questions by retrieving relevant chunks and generating responses with a language model.
  - Maintain fast responses via caching and efficient embedding strategies.

Architecture overview (high-level)
- Layered design with modular microservices and a data-centric loop.
  - Ingestion/Indexing Layer
    - Modules responsible for collecting data: GitHub repositories, PDFs, and text content.
    - Produces chunked, metadata-rich content suitable for embedding.
  - Embedding & Vector Store Layer
    - EmbeddingService uses OpenAI embeddings (v1 async) to convert text chunks into vector representations.
    - Qdrant vector store persists embeddings across distinct collections.
  - Retrieval & Reasoning Layer
    - Embedding-driven similarity search against Qdrant to fetch relevant chunks.
    - A lightweight orchestrator (rag_system.py) coordinates retrieval, summarization, and answer generation using OpenAI models.
  - Caching & Performance Layer
    - Redis cache to speed up repeated access and reduce repeated embedding calls where appropriate.
  - Presentation & API Layer
    - FastAPI-based interface (rag_system.py) serves REST endpoints, handles file uploads, and provides static assets for admin UI or dashboards.
  - UI & Public Assets
    - Static frontend assets served from FastAPI (StaticFiles) and public HTML/JS resources in modules (web UIs for RAG, browser, etc.).
- Data persistence and services
  - Qdrant: Vector store with dedicated collections for different data types.
  - Redis: Cache layer for quick lookups and potential session/state management.
  - OpenAI embeddings and generation: Core AI services for encoding and response generation.
- Deployment model
  - Docker-based multi-service setup (Dockerfiles and docker-compose files across modular-framework and its modules: RAG, browser, github-hub, llm-chat).
  - Each module encapsulates its own service(s) and assets, enabling isolated scaling and update paths.

Key components and responsibilities

1) RAG module (rag_system.py)
- Core responsibilities:
  - Orchestrates the RAG workflow: ingestion of content, embedding, storage in Qdrant, and answer generation.
  - Exposes API endpoints (FastAPI) for ingestion, querying, and admin operations (prefixed by /admin-api).
  - Provides a simple, production-friendly async interaction with OpenAI’s embedding API (AsyncOpenAI).
- Data model and storage:
  - Uses three main Qdrant collections: code, documents, conversations.
  - Each chunk is represented by a CodeChunk dataclass with fields: content, file_path, repo_name, language, start_line, end_line, chunk_type.
  - Embedding dimensions are aligned with the selected embedding model (RAG_EMBED_MODEL), with a mapping EMBED_DIMS to ensure consistency across collections.
- Embedding strategy:
  - EmbeddingService supports single and batch embeddings with micro-batching (EMBED_MICROBATCH) and token-truncation to respect model constraints.
  - Token truncation uses tiktoken (cl100k_base) to enforce a maximum token count per input.
  - Batch embedding includes a robust fallback: if a micro-batch fails, attempt per-item embedding to isolate problematic inputs.
- Chunking strategy:
  - CodeChunk chunking uses a CodeChunk data model and a ChunkingService to produce token-limited chunks with line mappings.
  - Language inferred from file extension, ensuring context is preserved per chunk.
  - Enforces hard token limit per chunk (via CHUNK_TOKENS_HARD) and splits oversized content while preserving line references (start_line, end_line).
- Metadata and search:
  - Chunks include metadata like file_path, repo_name, language, and code_block vs. other chunk types to support filtered searches.

2) Ingestion & Data sources
- RAG module ingests content from:
  - GitHub repositories (via github-hub module)
  - PDFs and text files (via ingestion logic in rag_system.py)
- Data is chunked, embedded, and stored in the appropriate Qdrant collection with suitable metadata for disambiguation and scoping during retrieval.

3) Vector store and cache
- Qdrant
  - Collections: code, documents, conversations, all sharing the same embedding dimension and cosine distance.
  - Provides fast vector similarity search with metadata filtering capabilities.
- Redis
  - Acts as a caching layer to reduce repeated work for hot queries or repeated embeddings.

4) AI models and endpoints
- Embedding model
  - RAG_EMBED_MODEL defaults to text-embedding-3-small (1536 dims) but can be overridden via environment variable.
- Reasoning and generation
  - Summary and answer models: RAG_SUMMARY_MODEL and RAG_ANSWER_MODEL (defaults suggest GPT-4o-mini).
  - OpenAI Async client (AsyncOpenAI) is used for both embeddings and generation flows.

Security model

- API exposure
  - FastAPI app with CORS policy allowing all origins (allow_origins=["*"]) for development convenience; production should tighten to trusted origins.
  - Admin endpoints prefixed with /admin-api to separate admin vs. user flows; authentication/authorization can be layered on these endpoints.
- Secrets management
  - API keys and endpoints (OpenAI API key, Qdrant URL, Redis host) are sourced from environment variables, enabling secure secret management and easy rotation.
- Data governance
  - Data is stored in Redis and Qdrant with metadata; sensitive content handling should consider access controls, data residency, and audit logging.

Data flow at a high level (10,000-foot view)

- Ingest
  - Data sources (GitHub repos, PDFs, plain text) are ingested by ingestion modules.
  - Content arrives at the RAG system, where it is parsed and prepared for embedding.
- Chunking
  - The content is split into chunks (CodeChunk) with careful token accounting and line mappings to keep track of source context.
- Embedding
  - Chunks are embedded using OpenAI embeddings via the EmbeddingService.
  - Micro-batching is used to optimize throughput; if a batch fails, per-item fallback is attempted to isolate offenders.
- Indexing
  - Embeddings are written to Qdrant into their respective collections (code, documents, conversations) with associated metadata.
- Retrieval
  - At query time, the system uses nearest-neighbor retrieval against the relevant collection(s) to fetch top-relevant chunks.
  - Metadata enables filtering (e.g., by language, file path, repo).
- Reasoning and generation
  - Retrieved chunks are fed to a generation model to produce an answer or summary.
  - Depending on the flow, a summarization step may occur before answering, guided by RAG_SUMMARY_MODEL and RAG_ANSWER_MODEL.
- Delivery
  - Results are delivered via the FastAPI endpoints and optionally surfaced through static UI assets (admin/dashboard).

Key design decisions

- Separation of data domains via collections
  - Distinct Qdrant collections for code, documents, and conversations enable targeted retrieval strategies and tailored embeddings/search behaviors per data type.
- Embedding model choice and token safety
  - Use a compact embedding model (text-embedding-3-small) to balance cost and quality for small orgs, with token-truncation and hard chunking to respect model limits.
- Micro-batching with robust fallbacks
  - Micro-batching accelerates throughput; per-item fallback isolates problematic inputs without aborting the entire batch.
- Token-aware chunking
  - Chunking respects token budgets, preserves line mappings, and ensures chunks are neither too large to fail nor too small to be inefficient.
- Caching for performance
  - Redis caching reduces repeated work, speeding up common queries and saving on embedding/API costs.
- Async-first architecture
  - Async OpenAI client and FastAPI support scalable, concurrent request handling.
- Configuration via environment
  - All critical knobs (model names, collections, endpoints, and limits) are configurable via environment variables, aiding portability and deployment flexibility.
- Observability
  - Logging via loguru to rag_system.log with rotation and retention policies supports operational monitoring and troubleshooting.
- Operational flexibility
  - Dockerized modules with docker-compose support allow isolated deployment, testing, and scaling of each component (RAG, browser, GitHub integration, LLM chat).

Security considerations and recommended hardening

- Tighten CORS in production: limit origins to known dashboards or apps.
- Authenticate admin APIs: add token-based authentication or OAuth for endpoints under /admin-api.
- Secrets management: use a secrets manager (e.g., Kubernetes Secrets, AWS Secrets Manager) rather than environment variables in production.
- Data access controls: implement fine-grained access controls for Qdrant and Redis, and log access events for auditing.
- Data retention policies: define retention for embeddings, chunk data, and logs to comply with data governance requirements.

Deployment and ops notes

- Deployment model
  - The repository includes Dockerfiles and docker-compose configurations for the modular framework and each module (RAG, browser, github-hub, llm-chat).
  - This enables local development, CI/CD pipelines, and scalable deployments in containerized environments.
- Observability
  - Centralized logging (rag_system.log) supports debugging, with rotation and retention configured.
  - Consider adding metrics (e.g., request latency, Qdrant query times, cache hit rate) and tracing for deeper observability.
- Scaling considerations
  - OpenAI embeddings and generation calls are async; scale RAG compute by increasing the number of workers/instances behind the API, and scale Redis/Qdrant independently as data grows.
  - If ingestion volume grows, consider asynchronous ingestion pipelines and incremental reindexing strategies.

Weaknesses and opportunities for improvement (shortlist)

- Authentication and API security should be hardened for production (currently permissive CORS and no explicit auth for admin endpoints in the snippet).
- Data governance and privacy policies need explicit definition, especially around code and documents with potential IP or sensitive information.
- Advanced filtering and ranking strategies could be added (e.g., per-repo scoring, user context, or conversation history relevance).
- Observability could be enhanced with metrics, traces, and dashboards to monitor ingestion throughput and latency.

In summary
The system provides a modular, scalable approach to productionized RAG for small organizations by combining:
- a data ingestion pipeline (GitHub, PDFs, text),
- a token-aware chunking and embedding strategy,
- a Qdrant-based vector store with dedicated collections per data type,
- an async, OpenAI-driven embedding/generation workflow,
- Redis caching to speed repeated queries,
- and a FastAPI-based API layer with static UI assets for administration and exploration.

This architecture supports fast retrieval-augmented responses, while keeping data organized, scalable, and adaptable through environment-driven configuration and Dockerized deployments.